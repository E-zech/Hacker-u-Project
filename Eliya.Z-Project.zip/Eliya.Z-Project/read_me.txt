** Open All Project With Live Server **
* This Website is responsive from 350px up to 4000px .
*Fun Fact - all of the gallery photos were shot in New Zealand .